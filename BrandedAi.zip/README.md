<h2 align="center">
         ──「 𝗕𝗥𝗔𝗡𝗗𝗘𝗗 𝗔𝗶 𝗖𝗛𝗔𝗧 𝗕𝗢𝗧 」──



<p align="center">

<img src="https://te.legra.ph/file/2e2f78610814092d61103.jpg">
</p>

# About

𝗔𝗻 𝗔𝗱𝘃𝗮𝗻𝗰𝗲𝗱 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 𝗜𝗱 𝗖𝗵𝗮𝘁𝗯𝗼𝘁 𝗢𝗽𝗲𝗻 𝗦𝗼𝘂𝗿𝗰𝗲 𝗖𝗼𝗱𝗲.

## How To Host

𝗧𝗵𝗲 𝗲𝗮𝘀𝗶𝗲𝘀𝘁 𝘄𝗮𝘆 𝘁𝗼 𝗱𝗲𝗽𝗹𝗼𝘆 𝘁𝗵𝗶𝘀 𝗕𝗼𝘁

• 𝐄𝐧𝐭𝐞𝐫 𝐲𝐨𝐮𝐫 MONGO_URL,API_ID, API_HASH And SESSION.

### Deploy To Heroku 🚀

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/WCGKING/BRANDED-AI"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
 
## Reach Me

<p align="center"><a href="https://t.me/BRANDEDKING82"> <img src="https://img.shields.io/badge/Telegram%20Id-black?style=for-the-badge&logo=Telegram" width="200" height="38.45"/></a></p>

## Support 

<p align="center"><a href="https://t.me/BRANDED_WORLD"> <img src="https://img.shields.io/badge/Support%20Group-black?style=for-the-badge&logo=Telegram" width="220" height="38.5"/></a></p> 

<p align="center">
<a href="https://t.me/BRANDRD_BOT"> <img src="https://img.shields.io/badge/Support%20Group-black?style=for-the-badge&logo=Telegram" width="220" height="38.5"/></a></p> 



<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʟᴏᴄᴀʟ ʜᴏsᴛ/ ᴠᴘs 」─
</h3>

- Get your [Necessary Variables](https://github.com/WCGKING/BRANDED-AI/blob/master/sample.env)

- Upgrade and Update by : sudo apt-get update && sudo apt-get upgrade -y
- Clone the repository by : git clone https://github.com/WCGKING/BrandedAi && cd BrandedAi
- Install requirements by : pip3 install -U -r requirements.txt
- Fill your variables in the env by : vi sample.env
- Press I on the keyboard for editing env
- Press Ctrl+C when you're done with editing env and :wq to save the env
- Rename the env file by : mv sample.env .env
- Install tmux to keep running your bot when you close the terminal by : sudo apt install tmux && tmux
- Finally run the bot by : bash start
- For getting out from tmux session : Press Ctrl+b and then d
